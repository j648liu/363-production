This is the final project for psych 363 taught by Britt Anderson.

This is created by Junwen (Ciel) Liu, Xinhe (Leah) Liu, and Shuveta Gupta.

For ease of viewing, the project was partitioned into two. 

More info inside the repositories. 