- This partition is the report writing phase of the project.

- Everything starts with all_data.csv, the combined data for all participants.

- production_effect.org is the write up for the report.

- analysis.R contains all the R codes used for data analysis. Different parts of production_effect.org sourced these pieces of codes.

- Sourcing R codes and executing them in Org Mode Emacs produced some in text results, and also comparison1.png and comparison2.png

- ref.bib contains references.

- Exporting the org file creates production_effect.tex.

- Did the following sequence of commands in terminal to produce production_effect.pdf:
	pdflatex production_effect.tex
	bibtex production_effect
	pdflatex production effect.tex