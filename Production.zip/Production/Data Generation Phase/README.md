- This partition of the project contains everything before data analysis.

- experiment.py is the research program. It imports additional items from list.py

- experiment.py produces data files with naming patterns "results_.*csv"

- compile.R browses all data files in this repository under the above name pattern and combines them together, adding two new columns: gender and ID.

- compile.R outputs a file called all_data.csv, containing data for all participants.