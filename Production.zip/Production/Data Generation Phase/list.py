silent_list = ['forest','pocket','traffic','machine','leather',
'lesson','branch','invention','station','education',
'history','village','theatre','wagon','minute',
'factory','direction','century','amount','record']

read_list = ['debate','furniture','wheel','address','judge',
'ticket','account','powder','uniform','teacher',
'answer','package','quarrel','victory','captain',
'trousers','shoulder','afternoon','election','ocean']

distractor_list = ['resort','laugh','market','capital','industry',
'entrance','school','dinner','vacation','clothes',
'partner','merchant','foundation','stream','garden',
'kettle','winter','glass','beauty','queen']

#event core visual
